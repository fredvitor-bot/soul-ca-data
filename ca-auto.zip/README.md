# Atualização semanal – Motor Home USA (Cruise America)

1. Criar um repositório **público** no GitHub (ex.: `soul-ca-data`) e subir estes arquivos
   (`parse_ca.py`, `.github/workflows/update.yml`, pasta `public/` com o JSON atual).
2. Em Settings > Actions > General, permitir "Read and write permissions".
3. Aba Actions > "Atualizar disponibilidade Cruise America" > Run workflow (teste).
4. A página lê: https://raw.githubusercontent.com/<USUARIO>/soul-ca-data/main/public/cruise-america-availability.json

Se o PDF mudar de layout, o script aborta e mantém o último JSON bom (o job fica vermelho).
Valores (preços) NÃO vão neste repositório público: `--rates-out` só deve ser usado em ambiente privado.
